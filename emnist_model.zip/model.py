from tensorflow.keras import Input, Model
from tensorflow.keras.layers import Conv2D, MaxPool2D, Dense, Flatten, Dropout


def lenet(input_shape, num_classes):
    inp = Input(shape=input_shape)
    x = Conv2D(filters=20, kernel_size=5, strides=1)(inp)
    x = MaxPool2D(pool_size=2, strides=2)(x)
    x = Conv2D(filters=50, kernel_size=5, strides=1)(x)
    x = MaxPool2D(pool_size=2, strides=2)(x)
    x = Flatten()(x)
    x = Dense(500, activation='relu')(x)
    x = Dense(num_classes, activation='softmax')(x)

    return Model(inp, x, name='lenet-none')
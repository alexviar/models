import argparse
import os
import tensorflow as tf
from tensorflow.keras import utils
import numpy as np
from load_data import load, load_images, load_labels

from model import lenet

def normalize_data(data):
    data = data.reshape((data.shape[0], data.shape[1], data.shape[2], 1))
    return data.astype(np.float32) / 255

def filter_by_label(images, labels, label, new_label):
    images = images[np.where(labels == label)]
    return images, np.full(images.shape[0], new_label)

def shuffle_in_unison(a, b):
    rng_state = np.random.get_state()
    np.random.shuffle(a)
    np.random.set_state(rng_state)
    np.random.shuffle(b)

def prepare_data(data_dir):
    #(X_train, Y_train), (X_test, Y_test) = mnist.load_data()    
    #https://www.itl.nist.gov/iaui/vip/cs_links/EMNIST/gzip.zip
    (X_train, Y_train), (X_test, Y_test) = load(
      os.path.join(data_dir, "emnist-digits-train-images-idx3-ubyte.gz"),
      os.path.join(data_dir, "emnist-digits-train-labels-idx1-ubyte.gz"),
      os.path.join(data_dir, "emnist-digits-test-images-idx3-ubyte.gz"),
      os.path.join(data_dir, "emnist-digits-test-labels-idx1-ubyte.gz")
    )

    (X_train_letters, Y_train_letters), (X_test_letters, Y_test_letters) = load(
      os.path.join(data_dir, "emnist-letters-train-images-idx3-ubyte.gz"),
      os.path.join(data_dir, "emnist-letters-train-labels-idx1-ubyte.gz"),
      os.path.join(data_dir, "emnist-letters-test-images-idx3-ubyte.gz"),
      os.path.join(data_dir, "emnist-letters-test-labels-idx1-ubyte.gz")
    )

    X_train_letters, Y_train_letters = filter_by_label(X_train_letters, Y_train_letters, 'x', 10)
    X_test_letters, Y_test_letters = filter_by_label(X_test_letters, Y_test_letters, 'x', 10)
    
    X_train = np.concatenate((X_train, X_train_letters))
    Y_train = np.concatenate((Y_train, Y_train_letters))
    X_test = np.concatenate((X_test, X_test_letters))
    Y_test = np.concatenate((Y_test, Y_test_letters))

    shuffle_in_unison(X_train, Y_train)
    shuffle_in_unison(X_test, Y_test)

    X_train = normalize_data(X_train)
    X_test = normalize_data(X_test)

    Y_train, Y_test = utils.to_categorical(Y_train, 11), utils.to_categorical(Y_test, 11)

    return (X_train, Y_train), (X_test, Y_test)


def main(args):
    if (args.result_dir[0] == '$'):
        RESULT_DIR = os.environ[args.result_dir[1:]]
    else:
        RESULT_DIR = args.result_dir

    model_path = os.path.join(RESULT_DIR, 'model')
    if (args.data_dir[0] == '$'):
        DATA_DIR = os.environ[args.data_dir[1:]]
    else:
        DATA_DIR = args.data_dir

    # load the data
    (X_train, Y_train), (X_test, Y_test) = prepare_data(DATA_DIR)

    # prepare the model
    model = lenet
    model = model(
        input_shape=X_train.shape[1:],
        num_classes=11,
    )
    
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['acc'])

    # train the network
    model.fit(
        x=X_train,
        y=Y_train,
        batch_size=args.batch_size,
        epochs=args.epochs,
        validation_split=0.2
    )

    # evaluate the model
    (_, acc) = model.evaluate(
        x=X_test,
        y=Y_test,
        batch_size=args.batch_size
    )
    print('Validation accuracy: {}'.format(acc))
    model.save(os.path.join(model_path, 'model.h5'), save_format='h5')
    os.system('(cd $RESULT_DIR/model;tar cvfz ../saved_model.tgz .)')
    print(str(os.listdir(os.environ['RESULT_DIR'])))
    print(os.environ['RESULT_DIR'])
    sys.stdout.flush()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='emnist experiment')
    parser.add_argument('--epochs', '-e', type=int, default=20)
    parser.add_argument('--batch_size', '-b', type=int, default=128)
    parser.add_argument('--data_dir', type=str, default='$DATA_DIR',
                        help='Directory with data')
    parser.add_argument('--result_dir', type=str, default='$RESULT_DIR',
                        help='Directory with results')

    args_ = parser.parse_args()

    main(args_)